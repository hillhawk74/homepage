#include <iostream>
#include <sstream>
#include <fstream>
#include <math.h>
#include <time.h>
#include <vector>
#include <stdio.h>

using namespace std;

void init(vector<vector<double> >	&im, 
		  vector<double>			&cluster, 
		  vector<vector<int> >		&cluster_mark);

void ewcvt(vector<vector<double> >	&im, 
		  vector<double>			&cluster, 
		  vector<vector<int> >		&cluster_mark,
		  double beta, int w);

void ewvt(vector<vector<double> >	&im, 
		  vector<double>			&cluster, 
		  vector<vector<int> >		&cluster_mark,
		  double beta, int w);

double ewdist_to_cluster(vector<vector<double> > &im, 
	                     vector<double> &cluster,
						 vector<vector<int> > &cluster_mark,
						 int i, int j, int l, double beta, int w);

void output(vector<vector<int> > mark, int ite);

//int	times;
int main(){

	int			n;			//	grid no.
	int			w;			//	NB size
	int			cn;			//  No. of the clusters
	double		beta;		//	smoothe parameter
	string		fn;			//	data file name

	
//====	parse the input.txt
	string		str;
	istringstream ss;
	ifstream fin("input.txt");


	if(!fin){
		cout<<"Open input.txt failed!"<<endl;
       	exit(1);
    }
	
	
	fin>>str;
	str = str.substr(2, str.length()-1);
	ss.str(str);
	ss>>n;


	fin>>str;	
	str = str.substr(3, str.length()-2);
	ss.clear();
	ss.str(str);
	ss>>w;
	
	fin>>str;	
	str = str.substr(5, str.length()-4);
	ss.clear();
	ss.str(str);
	ss>>beta;

	fin>>fn;

	fin>>str;	
	str = str.substr(3, str.length()-2);
	ss.clear();
	ss.str(str);
	ss>>cn;

	vector<double> cluster(2, 0.0);
	fin>>cluster[0];
	fin>>cluster[1];

//====Output input.txt
	
	cout<<"=================================================\n";
	cout <<"\tDomain is        : [-1 1] * [-1 1]"<<endl;
	cout <<"\tImage Size is    : "<<n<<endl;
	cout <<"\tSmooth para. is  : "<<beta<<endl;
	cout <<"\tNB size is       : "<<w<<endl;
	cout <<"\tData File is     : "<<fn<<endl;
	cout <<"\tNO. of clusters  : "<<cn<<endl;
	cout<<"=================================================\n";


//====	Read the data file
	//ifstream	df(fn.c_str());
	FILE	*df;
	df = fopen(fn.c_str(),"r");

	if(!df){
		cout<<"File "<<fn<<" open failure!"<<endl;
		exit(1);
	}
	vector<vector<double> > im(n, vector<double>(n, 0.0));
	vector<vector<int> > cluster_mark(n, vector<int>(n, 0));
	for(int i = 0; i < n; i++){
		for(int j = 0; j < n; j++){
			fscanf(df, "%lf%*c", &im[i][j]);
		}
	}
//=============================Reading done

//===	Doing EWCVT here 
	init(im, cluster, cluster_mark);
	ewcvt(im, cluster, cluster_mark, beta, w);
//=============================done

}

//============================
//	Input:
//		im
//		cluster
//	Output
//		cluster_mark		
void init(vector<vector<double> > &im, vector<double> &cluster, vector<vector<int> > &cluster_mark){
	
//====	Give the initial partition according to 
//		initial clusters
	int tempcl;
	double diff;
	for (int i = 0; i < im.size() ; i++)
	{
		for(int j = 0; j < im[0].size(); j++){
			diff = fabs(im[i][j] - cluster[0]);
			tempcl = 0;
			for(int k = 1; k < cluster.size(); k++){
				if(fabs(im[i][j] - cluster[k]) < diff){
					tempcl = k;
					diff = fabs(im[i][j] - cluster[k]);
				}
			}
			cluster_mark[i][j] = tempcl;
		}

	}

}


void ewcvt(vector<vector<double> > &im, 
           vector<double> &cluster, 
		   vector<vector<int> > &cluster_mark,
		   double beta, int w)
{
	vector<double> newcluster = cluster;
	int no = 0;
	double val = 0.0;
	int flag = 0;		// equality hold flag
	int ite;			// iteration
	double time = 0.0;

//	times = 0;
	for(ite = 0; ite<20 ;ite++)
	{
		cout<<ite<<endl;
		cout<<"old : "<<cluster[0]<<" and " << cluster[1]<<endl;
		
		double t1, t2;
		t1 = clock();
		ewvt(im, cluster, cluster_mark, beta, w);

//==== update new center
		for(int k = 0; k < cluster.size(); k++){
			no = 0; val = 0.0;

			for(int i = 0; i < im.size(); i++){
				for(int j = 0; j < im[0].size(); j++){
					if(cluster_mark[i][j] == k){
						no++;
						val += im[i][j];
					}
				}
			}

			if(no == 0){
				cout<<"Cluster : "<<k<<" has no point now!"<<endl;
				exit(1);
			}

			newcluster[k] = val / no;
		}//for(int k)
		cout<<"new : "<<newcluster[0]<<" and " << newcluster[1]<<endl;
//============================================================		

		for(int l = 0; l < cluster.size(); l++){
			if(fabs(newcluster[l]-cluster[l])>1e-4) flag = 1;
		}
		t2 = clock();

		time += difftime(t2, t1)/CLOCKS_PER_SEC;

		output(cluster_mark, ite);
		if(flag == 0) break;

		for(int kl = 0; kl < cluster.size(); kl++){
			cluster[kl] = newcluster[kl];
		}
		
		flag = 0;
		//times++;
	}//end for-loop

	cout<<"Elapsed Time : "<<time<<"s"<<endl;
	
}


void ewvt(vector<vector<double> > &im, 
          vector<double> &cluster, 
		  vector<vector<int> > &cluster_mark,
		  double beta, int w)
{
	
	double diff, diff1;
	int		cl;

	for(int tt = 0; tt < 1; tt++){
	for (int i = 0; i < im.size() ; i++)
	{
		for(int j = 0; j < im[0].size(); j++){
			cl = cluster_mark[i][j];
			diff = ewdist_to_cluster(im, cluster, cluster_mark, 
				                     i, j, cl, beta, w);
			for(int k = 0; k < cluster.size(); k++){
	
				diff1 = ewdist_to_cluster(im, cluster, 
										  cluster_mark, 
					                      i, j, k, beta, w);
				if(diff1 < diff){
					cl = k;
					diff = diff1;
				}
			}
			cluster_mark[i][j] = cl;
		}

	}
	}
}


//=================================
//	at the (i,j) pixel 
//	Compute edge-weighted dist to l-cluster
//=================================
//
double ewdist_to_cluster(vector<vector<double> > &im, 
	                     vector<double> &cluster,
						 vector<vector<int> > &cluster_mark,
						 int i, int j, int l, double beta, int w)
{
	double fidelity;
	double ratio;
	int nb;
	int sznb;
	int upi = im.size();		// upperbound for i 
	int upj = im[0].size();		// upperbound for j
	int	nl = 0;					// No. of pixel in l-th cluster
	
	nb = (2*w + 1);
	sznb = nb * nb;
	// fidelity term
	fidelity = fabs(im[i][j] - cluster[l]);
	// edge-dist in a neighbor
	for(int m = -w; m <= w; m++){
		for(int n = -w; n <= w; n++){
			// test the neighbor is within the domain 
			if((i+m < upi) && ((i+m) >= 0) && (j+n < upj) && ((j+n) >= 0)){
				// not itself
				if(m != 0 || n != 0){
					if(cluster_mark[i+m][j+n] == l)
						nl ++;
				}
			}
		}
	}

	//compute the adaptive ratio
	vector<int>	nc(cluster.size(),0);
	for(int m = -w; m <= w; m++){
		for(int n = -w; n <= w; n++){
			// test the neighbor is within the domain 
			if((i+m < upi) && ((i+m) >= 0) && (j+n < upj) && ((j+n) >= 0)){
				// not itself
				if(m != 0 || n != 0){
					nc[cluster_mark[i+m][j+n]]++;
				}
			}
		}
	}

	ratio = 1 + 50*(fabs(nc[0] - nc[1]) / (double)(sznb));
	//ratio = exp(-1*ratio);
//	if(0.95 < ratio)
//		ratio = 1.0;
//	else if(0.4 < ratio && ratio <= 0.6  )
//		ratio = 0.01;
//	else if(0.1 < ratio && ratio <= 0.4  )
//		ratio = 1;
//	else
//		ratio = 1;
	//cout<<ratio<<endl;
	//return beta;	
	//cout<<fidelity * ratio + 2 * beta * (sznb - nl - 1)<<endl;
	return fidelity * ratio  + 2 * beta * (sznb - nl - 1);
}


void output(vector<vector<int> > mark, int ite){
	
	string	str;
	ostringstream ss;

	ss << ite;
	str = "output";
	str += ss.str();
	str += ".txt";

	ofstream fout(str.c_str());
	for(int i = 0; i < mark.size(); i++){
		for(int j = 0; j < mark[0].size();j++){
			fout<<mark[i][j]<<" ";
		}
		fout<<endl;	
	}
}
