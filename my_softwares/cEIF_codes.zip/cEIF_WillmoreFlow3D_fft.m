function cEIF_WillmoreFlow3D_fft(N,M,L,K,bct,ord)
format long

%This program solve the Willmore flow equation 
%  f = epsilon\Delta(u)-(u^3-u)/epsilon
%  u_t = \Delta(f)-(3u^2-1)f
%      st. vol = \alpha, sur = \beta

%Boundary condition type
%bct = 1; % Periodic bc
%bct = 2; % No-flux bc

%Order of accuracy in time
%ord = 1; 
%ord = 2; 
%ord = 3; 

%Domain
%  [xb,xe] x [yb,ye] x [zb,ze]
%Number of grid sizes 
%   N x M x L
%Time interval
%  [T0,Te] 
%Number of step sizes
%   K

%Cahn-Hilliard parameters
global epsilon;
global kappa;
global D;
global init_vol;
global curr_vol;
global init_sur;
global curr_sur;
epsilon = 0.02;
kappa = 2;
D = 3/2;

xb = -0.5; xe = 0.5; yb = -0.5; ye = 0.5; zb = -0.5; ze = 0.5;
T0 = 0; Te = 1;
hx = (xe-xb)/N;  hy = (ye-yb)/M;  hz = (ze-zb)/L;
x = xb:hx:xe;  y = yb:hy:ye;  z = zb:hz:ze;
dt = (Te-T0)/K;  T = T0:dt:Te;

fprintf(1,'\n *************************************************\n');
fprintf(1,'\n --- Parameters and Mesh Sizes ---\n');
fprintf(1,'\n epsilon = %e, D = %e\n',epsilon,D);
fprintf(1,'\n Nx = %d, Ny = %d, Nz = %d, Nt = %d\n',N,M,L,K);
fprintf(1,'\n hx = %e, hy = %e, hz = %e, dt = %e\n',hx,hy,hz,dt);
if bct==1
   fprintf(1,'\n Boundary Condition Type: Periodic\n');
end
if bct==2
   fprintf(1,'\n Boundary Condition Type: Neumann \n');
end

%Compute A,B,C
global A;
global B;
global C;
if bct==1
   NN = N; MM = M; LL = L;
   A = sparse(NN,NN);  B = sparse(MM,MM);  C = sparse(LL,LL); 
   for i=1:NN-1
       A(i,i) = -2;  A(i,i+1) = 1;  A(i+1,i) = 1;
   end
   A(NN,NN) = -2;  A(1,NN) = 1;  A(NN,1) = 1;
   for i=1:MM-1
       B(i,i) = -2;  B(i,i+1) = 1;  B(i+1,i) = 1;
   end
   B(MM,MM) = -2;  B(1,MM) = 1;  B(MM,1) = 1;
   for i=1:LL-1
       C(i,i) = -2;  C(i,i+1) = 1;  C(i+1,i) = 1;
   end
   C(LL,LL) = -2;  C(1,LL) = 1;  C(LL,1) = 1;
end
if bct==2
   NN = N+1; MM = M+1; LL = L+1;
   A = sparse(NN,NN);  B = sparse(MM,MM);  C = sparse(LL,LL);
   for i=1:NN-1
       A(i,i) = -2;  A(i,i+1) = 1;  A(i+1,i) = 1;
   end
   A(NN,NN) = -2;  A(1,2) = 2; A(NN,NN-1) = 2;
   for i=1:MM-1
       B(i,i) = -2;  B(i,i+1) = 1;  B(i+1,i) = 1;
   end
   B(MM,MM) = -2;  B(1,2) = 2;  B(MM,MM-1) = 2;
   for i=1:LL-1
       C(i,i) = -2;  C(i,i+1) = 1;  C(i+1,i) = 1;
   end
   C(LL,LL) = -2;  C(1,2) = 2;  C(LL,LL-1) = 2;
end

%Diagonalize A,B,C
A = A/(hx*hx);
B = B/(hy*hy);
C = C/(hz*hz);

if bct==1
   NN = N; MM = M; LL = L;
   Dx = -4*(1/(hx*hx))*(sin((0:NN-1)*pi/NN)).^2;
   Dy = -4*(1/(hy*hy))*(sin((0:MM-1)*pi/MM)).^2;
   Dz = -4*(1/(hz*hz))*(sin((0:LL-1)*pi/LL)).^2;
end
if bct==2
   NN = N+1; MM = M+1; LL = L+1;
   N2 = 2*N; M2 = 2*M; L2 = 2*L;
   Dx = -4*(1/(hx*hx))*(sin((0:NN-1)*pi/N2)).^2;
   Dy = -4*(1/(hy*hy))*(sin((0:MM-1)*pi/M2)).^2;
   Dz = -4*(1/(hz*hz))*(sin((0:LL-1)*pi/L2)).^2;
end

Het = zeros(NN,MM,LL);
phi = zeros(NN,MM,LL,3);
for i=1:NN
    for j=1:MM
        for l = 1:LL
            Hijl = epsilon*(Dx(i)+Dy(j)+Dz(l))^2-kappa*(Dx(i)+Dy(j)+Dz(l))/epsilon ...
                   -D*(Dx(i)+Dy(j)+Dz(l)-kappa/epsilon^2)/epsilon;
            if abs(Hijl)>1.0e-5
               Het(i,j,l) = exp(-Hijl*dt); 
               phi(i,j,l,1) = (1-Het(i,j,l))/Hijl; 
               phi(i,j,l,2) = (1-phi(i,j,l,1)/dt)/Hijl;
               phi(i,j,l,3) = (1-2*phi(i,j,l,2)/dt)/Hijl;
            else
               Het(i,j,l) = 1;
               phi(i,j,l,1) = dt; 
               phi(i,j,l,2) = dt/2;
               phi(i,j,l,3) = dt/3;
            end
        end
    end
end

%Initialize U0
U = zeros(NN,MM,LL);
for i=1:NN
    for j=1:MM
        for l=1:LL
            U(i,j,l) = u0(x(i),y(j),z(l));
        end
    end
end

%load('ellipsoid-128x128.mat','U');

F = zeros(NN,MM,LL,3);

tic;

%Evolve U along the time
TK = K;
vol =  0:1:TK;
sur =  0:1:TK;
egy =  0:1:TK;
[vol(1),sur(1),egy(1)] = comput_Vol_Egy(U,hx,hy,hz,bct);
init_vol = vol(1);
curr_vol = init_vol;
init_sur = sur(1);
curr_sur = init_sur;
F(:,:,:,1) = iTrans(FF(U),bct);
kstop = TK;
c_ord = ord;
for k=1:TK
    itrue = 1;
    egy_old = egy(k);
    U_lin = iTrans(U,bct).*Het;
    while itrue==1
    U = Trans(U_lin+int_F(phi,F,min(min(k,ord),c_ord)),bct);
    U = real(U);
    [vol(k+1),sur(k+1),egy(k+1)] = comput_Vol_Egy(U,hx,hy,hz,bct);
    if egy_old<egy(k+1)&&c_ord>1
       c_ord = max(c_ord-1,1);  
    else
       c_ord = min(ord,c_ord+1);
       itrue = 0;
    end
    end
    if max(max(abs(U)))>2
       fprintf (1,'\n Fail to continue to run !!!\n');
       break;
    end
    if abs(egy_old-egy(k+1))<max(egy_old*1.0e-6,1.0e-10)
       kstop = k;
       break;
    end
    if k==1
       F(:,:,:,2) = F(:,:,:,1);
    end
    if k>1
       F(:,:,:,3) = F(:,:,:,2);
       F(:,:,:,2) = F(:,:,:,1);
    end
    curr_vol = vol(k+1);
    curr_sur = sur(k+1);
    F(:,:,:,1) = iTrans(FF(U),bct);
end

wtime = toc;
fprintf (1,'\n MY_PROGRAM took %f seconds to run !!!\n',wtime);

if kstop==TK
   fprintf(1,'\n --- A Steady State Had Not Been Reached at T = %e ---\n',T(kstop+1));
else
   fprintf(1,'\n --- A Steady State Was Reached at T = %e ---\n',T(kstop+1));
end
fprintf(1,'\n Minimal value = %f, Maximal value = %f\n',min(min(min(U))),max(max(max(U))));
fprintf(1,'\n Initial energy = %e, Final energy is %e\n',egy(1),egy(kstop+1));
fprintf(1,'\n Initial volume = %e, Final volume is %e\n',vol(1),vol(kstop+1));
fprintf(1,'\n Initial sfarea = %e, Final sfarea is %e\n',sur(1),sur(kstop+1));
fprintf(1,'\n *************************************************\n');

%save('ellipsoid-128x128.mat','U');

U_full = Recover(U,bct);
%Draw the solution at the end time 
fig1 = figure();
UU(:,:) = U_full(:,:,floor(LL/2)+1);
surf(x,y,UU','linestyle','none');
xlabel('X');
ylabel('Y');
axis equal;
colorbar;
view([0,0,1]); 
fig11 = figure();
UU(:,:) = U_full(floor(NN/2)+1,:,:);
surf(y,z,UU','linestyle','none');
xlabel('X');
ylabel('Y');
axis equal;
colorbar;
view([0,0,1]);

kk = 0:1:kstop;
fig2 = figure();
plot(T(1:kstop+1),vol(1:kstop+1),'.-');
xlabel('Time');
ylabel('Volume');
kk = 0:1:kstop;
fig3 = figure();
plot(T(1:kstop+1),sur(1:kstop+1),'.-');
xlabel('Time');
ylabel('Surface Area');
fig4 = figure();
semilogy(T(1:kstop+1),egy(1:kstop+1),'.-');
xlabel('Time');
ylabel('Energy');
end

function V = circle_x(P,U)
V = U;
for l=1:size(U,3)
    V(:,:,l) = P*U(:,:,l);
end
end

function V = circle_y(P,U)
V = U;
for i=1:size(U,1)
    U1(:,:) = U(i,:,:);
    V1 = P*U1;
    V(i,:,:) = V1;
end
end

function V = circle_z(P,U)
V = U;
for j=1:size(U,2)
    U1(:,:) = U(:,j,:);
    V1= U1*P'; 
    V(:,j,:) = V1;
end
end

function V = Trans(U,bct)
if bct==1
   V = fftn(U);
end
if bct==2
   V = rfft3(U);
end
end

function V = iTrans(U,bct)
if bct==1
   V = ifftn(U);
end
if bct==2
   V = irfft3(U);
end
end

function V = rfft3(U)
[Nx Ny Nz] = size(U);
UF = cat(1,U,flipdim(U(2:Nx-1,1:Ny,1:Nz),1));
UF = fft(UF); 
V = permute(UF(1:Nx,1:Ny,1:Nz),[2,3,1]);
UF = cat(1,V,flipdim(V(2:Ny-1,1:Nz,1:Nx),1));
UF = fft(UF);
V = permute(UF(1:Ny,1:Nz,1:Nx),[2 3 1]);
UF = cat(1,V,flipdim(V(2:Nz-1,1:Nx,1:Ny),1));
UF = fft(UF);
V = permute(UF(1:Nz,1:Nx,1:Ny),[2 3 1]);
end

function V = irfft3(U)
[Nx Ny Nz] = size(U);
UF = cat(1,U,flipdim(U(2:Nx-1,1:Ny,1:Nz),1));
UF = ifft(UF); 
V = permute(UF(1:Nx,1:Ny,1:Nz),[2,3,1]);
UF = cat(1,V,flipdim(V(2:Ny-1,1:Nz,1:Nx),1));
UF = ifft(UF);
V = permute(UF(1:Ny,1:Nz,1:Nx),[2 3 1]);
UF = cat(1,V,flipdim(V(2:Nz-1,1:Nx,1:Ny),1));
UF = ifft(UF);
V = permute(UF(1:Nz,1:Nx,1:Ny),[2 3 1]);
end

function int = int_F(phi,F,ord)
[NN MM LL nn] = size(F);
int = zeros(NN,MM,LL);
if ord==1
   int = phi(:,:,:,1).*F(:,:,:,1);
end
if ord==2 
   int = (phi(:,:,:,1)+phi(:,:,:,2)).*F(:,:,:,1)-phi(:,:,:,2).*F(:,:,:,2);
end
if ord==3 
   int = 0.5*(2*phi(:,:,:,1)+3*phi(:,:,:,2)+phi(:,:,:,3)).*F(:,:,:,1) ...
              -(2*phi(:,:,:,2)+phi(:,:,:,3)).*F(:,:,:,2) ...
              +0.5*(phi(:,:,:,2)+phi(:,:,:,3)).*F(:,:,:,3);
end 
end

function sumV = sum_V(V,bct)
[NN MM LL] = size(V);
if bct==1
   sumV = sum(sum(sum(V)));
end
if bct==2
   sumV = sum(sum(sum(V(2:NN-1,2:MM-1,2:LL-1)))) ...
         +0.5*(sum(sum(V(1,2:MM-1,2:LL-1)))+sum(sum(V(NN,2:MM-1,2:LL-1))) ...
              +sum(sum(V(2:NN-1,1,2:LL-1)))+sum(sum(V(2:NN-1,MM,2:LL-1))) ...
              +sum(sum(V(2:NN-1,2:MM-1,1)))+sum(sum(V(2:NN-1,2:MM-1,LL)))) ...
         +0.25*(sum(V(2:NN-1,1,1))+sum(V(2:NN-1,1,LL))+sum(V(2:NN-1,MM,1)) ...
               +sum(V(2:NN-1,MM,LL))+sum(V(1,2:MM-1,1))+sum(V(1,2:MM-1,LL)) ...
               +sum(V(NN,2:MM-1,1))+sum(V(NN,2:MM-1,LL))+sum(V(1,1,2:LL-1)) ...
               +sum(V(1,MM,2:LL-1))+sum(V(NN,1,2:LL-1))+sum(V(NN,MM,2:LL-1))) ...
         +0.125*(V(1,1,1)+V(1,MM,1)+V(1,1,LL)+V(1,MM,LL) ...
                +V(NN,1,1)+V(NN,MM,1)+V(NN,1,LL)+V(NN,MM,LL));
end
end

function sumU = sum_diff_U(U,hx,hy,hz)
global epsilon;
[NN MM LL] = size(U);
V = 0.5*epsilon*((U(2:NN,1:MM,1:LL)-U(1:NN-1,1:MM,1:LL))/hx).^2;
sumU = sum(sum(sum(V(1:NN-1,2:MM-1,2:LL-1))))+0.5*(sum(sum(V(1:NN-1,1:MM,1))) ...
       +sum(sum(V(1:NN-1,1:MM,LL)))+sum(sum(V(1:NN-1,1,1:LL)))+sum(sum(V(1:NN-1,MM,1:LL))));
V = 0.5*epsilon*((U(1:NN,2:MM,1:LL)-U(1:NN,1:MM-1,1:LL))/hy).^2;
sumU = sumU+sum(sum(sum(V(2:NN-1,1:MM-1,2:LL-1))))+0.5*(sum(sum(V(1:NN,1:MM-1,1))) ...
       +sum(sum(V(1:NN,1:MM-1,LL)))+sum(sum(V(1,1:MM-1,1:LL)))+sum(sum(V(NN,1:MM-1,1:LL))));
V = 0.5*epsilon*((U(1:NN,1:MM,2:LL)-U(1:NN,1:MM,1:LL-1))/hz).^2;     
sumU = sumU+sum(sum(sum(V(2:NN-1,2:MM-1,1:LL-1))))+0.5*(sum(sum(V(1:NN,1,1:LL-1))) ...
       +sum(sum(V(1:NN,MM,1:LL-1)))+sum(sum(V(1,1:MM,1:LL-1)))+sum(sum(V(NN,1:MM,1:LL-1))));
end

function [vol,sur,egy] = comput_Vol_Egy(U,hx,hy,hz,bct)
global epsilon;
global A;
global B;
global C;
[NN MM LL] = size(U);
%Computing volume
V = (U+1)/2;
vol = sum_V(V,bct)*hx*hy*hz;
%Computing surface area
if bct==1
   U_full = Recover(U,bct);
   sur = sum_diff_U(U_full,hx,hy,hz);
end
if bct==2
   sur = sum_diff_U(U,hx,hy,hz);
end
V = 0.25*(U.*U-1).^2/epsilon;
sur = sur+sum_V(V,bct);
sur = sur*hx*hy*hz*3/(2*sqrt(2));
%Computing energy
V = (circle_x(A,U)+circle_y(B,U)+circle_z(C,U))*epsilon+U.*(1-U.*U)/epsilon;
V = V.*V;
egy = sum_V(V,bct)*hx*hy*hz;
end

function U_full = Recover(U,bct)
[NN MM LL] = size(U);
if bct==1
   U_full = zeros(NN+1,MM+1,LL+1); 
   U_full(1:NN,1:MM,1:LL) = U(1:NN,1:MM,1:LL);
   U_full(1:NN,1:MM,LL+1) = U_full(1:NN,1:MM,1);
   U_full(1:NN,MM+1,1:LL+1) = U_full(1:NN,1,1:LL+1);
   U_full(NN+1,1:MM+1,1:LL+1) = U_full(1,1:MM+1,1:LL+1);
end  
if bct==2
   U_full = U;
end
end

function V = FF(U)
global epsilon;
global A;
global B;
global C;
global kappa;
global D;
global curr_vol;
global init_vol;
global curr_sur;
global init_sur;
%pen1 = 100000; pen2 = 0;
pen1 = 100000; pen2 = 10000;
UL = U.*(U.*U-1-kappa);
V = (circle_x(A,UL)+circle_y(B,UL)+circle_z(C,UL))/epsilon ...
    -D*UL/epsilon^3 ...
    +((3*U.*U-D-1)/epsilon+pen2*(curr_sur-init_sur)*epsilon) ...
    .*(circle_x(A,U)+circle_y(B,U)+circle_z(C,U) ...
    -(UL+kappa*U)/epsilon^2)-pen1*(curr_vol-init_vol);
end

function uu = u0(x,y,z)
global epsilon;
 R0 = 0.3;
 dr = max(max(abs(x),abs(y)),abs(z));
 uu = tanh((R0-dr)/(sqrt(2)*epsilon));
%R1 = 0.3; R2 = 0.3; R3 = 0.1;
%dr = sqrt((x/R1)^2+(y/R2)^2+(z/R3)^2);
%uu = tanh((dr-1)/(sqrt(2)*epsilon));
%R0 = 0.15;
%dr1 = sqrt((x-0.2)^2+y^2+z^2);
%dr2 = sqrt((x+0.2)^2+y^2+z^2);
%uu = tanh((R0-dr1)/(sqrt(2)*epsilon))+tanh((R0-dr2)/(sqrt(2)*epsilon))+1;
%uu = (-1+2*rand(1,1))*0.1;
%phi = 0.25;
%phi = 0.5;
%phi = 0.75;
%uu = 2*phi-1+(-1+2*rand(1,1))*0.2;
end