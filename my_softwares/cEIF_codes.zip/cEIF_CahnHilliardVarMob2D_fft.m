function cEIF_WillmoreFlow2D_fft(N,M,K,bct,ord)
format long

%This program solve the Cahn-Hilliard equation with variable mobility 
%  u_t = \div(Mu(u)\nabla((u^3-u)-epsilon^2\Delta(u)))

%Boundary condition type
%bct = 1; % Periodic bc
%bct = 2; % No-flux bc

%Order of accuracy in time
%ord = 1; 
%ord = 2; 
%ord = 3; 

%Domain
%  [xb,xe] x [yb,ye]
%Number of grid sizes 
%   N x M 
%Time interval
%  [T0,Te] 
%Number of step sizes
%   K

%Cahn-Hilliard parameters
global epsilon;
global D;
global kappa;
epsilon = 0.05;
kappa = 2;

xb = 0; xe = 4*pi; yb = 0; ye = 4*pi; T0 = 0; Te = 40;
hx = (xe-xb)/N;  hy = (ye-yb)/M;
x = xb:hx:xe;  y = yb:hy:ye;
dt = (Te-T0)/K;  T = T0:dt:Te;

fprintf(1,'\n *************************************************\n');
fprintf(1,'\n --- Parameters and Mesh Sizes ---\n');
fprintf (1,'\n Epsilon = %e\n',epsilon);
fprintf (1,'\n Nx = %d, Ny = %d, Nt = %d\n',N,M,K);
fprintf (1,'\n hx = %e, hy = %e, dt = %e\n',hx,hy,dt);
if bct==1
   fprintf(1,'\n Boundary Condition Type: Periodic\n');
end
if bct==2
   fprintf(1,'\n Boundary Condition Type: Neumann \n');
end

%Compute A and B
global A;
global B;
if bct==1
   NN = N; MM = M;
   A = sparse(NN,NN);  B = sparse(MM,MM);
   for i=1:NN-1
       A(i,i) = -2;  A(i,i+1) = 1;  A(i+1,i) = 1;
   end
   A(NN,NN) = -2;  A(1,NN) = 1;  A(NN,1) = 1;
   for i=1:MM-1
       B(i,i) = -2;  B(i,i+1) = 1;  B(i+1,i) = 1;
   end
   B(MM,MM) = -2;  B(1,MM) = 1;  B(MM,1) = 1;
end
if bct==2
   NN = N+1; MM = M+1;
   A = sparse(NN,NN);  B = sparse(MM,MM);
   for i=1:NN-1
       A(i,i) = -2;  A(i,i+1) = 1;  A(i+1,i) = 1;
   end
   A(NN,NN) = -2;  A(1,2) = 2; A(NN,NN-1) = 2;
   for i=1:MM-1
       B(i,i) = -2;  B(i,i+1) = 1;  B(i+1,i) = 1;
   end
   B(MM,MM) = -2;  B(1,2) = 2;  B(MM,MM-1) = 2;
end

%Diagonalize A,B
A = A/(hx*hx);
B = B/(hy*hy);

if bct==1
   NN = N; MM = M;
   Dx = -4*(1/(hx*hx))*(sin((0:NN-1)*pi/NN)).^2;
   Dy = -4*(1/(hy*hy))*(sin((0:MM-1)*pi/MM)).^2;
end
if bct==2
   NN = N+1; MM = M+1;
   N2 = 2*N; M2 = 2*M;
   Dx = -4*(1/(hx*hx))*(sin((0:NN-1)*pi/N2)).^2;
   Dy = -4*(1/(hy*hy))*(sin((0:MM-1)*pi/M2)).^2;
end

global il;
global ir;
global jl;
global jr;
il = zeros(NN); ir = zeros(NN); jl = zeros(MM); jr = zeros(MM); 
for i=1:NN
    il(i) = i-1; ir(i) = i+1;
    if bct==1
       if (i==1) il(i) = NN; end;
       if (i==NN) ir(i) = 1; end;
    end
    if bct==2
       if (i==1) il(i) = 2; end;
       if (i==NN) ir(i) = NN-1; end;
    end       
end           
for j=1:MM
    jl(j) = j-1; jr(j) = j+1;
    if bct==1
       if (j==1) jl(j) = MM; end;
       if (j==MM) jr(j) = 1; end;
    end
    if bct==2
       if (j==1) jl(j) = 2; end;
       if (j==MM) jr(j) = MM-1; end;
    end       
end

%Initialize U0
U = zeros(NN,MM);
for i=1:NN
    for j=1:MM
        U(i,j) = u0(x(i),y(j)); 
    end
end
%save('Dai-0.75-1024-1024-set1.mat','U');
%load('Dai-0.75-1024-1024-set1.mat','U');

F = zeros(NN,MM,3);

tic;

%Evolve U along the time
TK = K;
vol =  0:1:TK;
egy =  0:1:TK;
D = 0.5*(max(max(Mu(U)))+min(min(Mu(U))));
[Het,phi] = compute_HetPhi(Dx,Dy,dt);
F(:,:,1) = iTrans(FF(U,hx,hy),bct);
[vol(1),egy(1)] = comput_Vol_Egy(U,hx,hy,bct);
kstop = TK;
c_ord = ord;
for k=1:TK
    itrue = 1;
    egy_old = egy(k);
    U_lin = iTrans(U,bct).*Het;
    while itrue==1
    U = Trans(U_lin+int_F(phi,F,min(min(k,ord),c_ord)),bct);
    U = real(U);
    [vol(k+1),egy(k+1)] = comput_Vol_Egy(U,hx,hy,bct);
    c_ord
    if egy_old<egy(k+1)&&c_ord>1
       c_ord = max(c_ord-1,1);  
    else
       c_ord = min(ord,c_ord+1);
       itrue = 0;
    end
    end
    if max(max(abs(U)))>10
       fprintf (1,'\n Fail to continue to run !!!\n');
       break;
    end
    D_old = D;
    D = 0.5*(max(max(Mu(U)))+min(min(Mu(U))));
    if abs(D-D_old)>1.0e-3
       [Het,phi] = compute_HetPhi(Dx,Dy,dt);
    end
    if abs(egy_old-egy(k+1))<max(egy_old*1.0e-10,1.0e-12)
       kstop = k;
       break;
    end
    if k==1
       F(:,:,2) = F(:,:,1);
    end
    if k>1
       F(:,:,3) = F(:,:,2);
       F(:,:,2) = F(:,:,1);
    end
    F(:,:,1) = iTrans(FF(U,hx,hy),bct);
end

wtime = toc;
fprintf (1,'\n MY_PROGRAM took %f seconds to run !!!\n',wtime);
save('Zhang-Exp1-0.25-80-1024-1024-0.05-16000.mat','U','vol','egy','T');

if kstop==TK
   fprintf(1,'\n --- A Steady State Had Not Been Reached at T = %e ---\n', kstop*dt);
else
   fprintf(1,'\n --- A Steady State Was Reached at T = %e ---\n',kstop*dt);
end
fprintf(1,'\n Minimal value = %f, Maximal value = %f\n',min(min(U)),max(max(U)));
fprintf(1,'\n Initial energy = %e, Final energy is %e\n',egy(1),egy(kstop+1));
fprintf(1,'\n Initial volume = %e, Final volume is %e\n',vol(1),vol(kstop+1));
fprintf(1,'\n *************************************************\n');

U_full = Recover(U,bct);
%Draw the solution at the end time 
fig1 = figure();
surf(x,y,U_full','linestyle','none');
xlabel('X');
ylabel('Y');
axis equal;
colorbar;
view([0,0,1]);

kk = 0:1:kstop;
fig2 = figure();
plot(T(1:kstop+1),vol(1:kstop+1),'.-');
xlabel('Time');
ylabel('Volume');
fig3 = figure();
logTime = log(T(kstop/10+1:kstop+1)); logEgy = log(egy(kstop/10+1:kstop+1));
Eb1 = (length(logTime)*sum(logTime.*logEgy)-sum(logTime)*sum(logEgy))/ ...
     (length(logTime)*sum(logTime.^2)-(sum(logTime))^2);
Eb2 = (sum(logEgy)-Eb1*sum(logTime))/length(logTime);
fprintf(1,'\n Slope of Energy fitting =  %e\n',Eb1);
plot(logTime,logEgy,'.--',logTime,Eb1*logTime+Eb2,'r-','LineWidth',1);
xlabel('ln(T)');
ylabel('ln(E)');
legend('Data','Linear fit');
%fig3 = figure();
%plot(T(1:kstop+1),egy(1:kstop+1),'.-');
%xlabel('Time');
%ylabel('Energy');
end

function V = circle_x(P,U)
V = P*U;
end

function V = circle_y(P,U)
V = U*P';
end

function V = Trans(U,bct)
if bct==1
   V = fft2(U);
end
if bct==2
   V = rfft2(U);
end
end

function V = iTrans(U,bct)
if bct==1
   V = ifft2(U);
end
if bct==2
   V = irfft2(U);
end
end

function V = rfft2(U)
[Nx Ny] = size(U);
UF = cat(1,U,flipdim(U(2:Nx-1,1:Ny),1));
UF = fft(UF); 
V = UF(1:Nx,1:Ny);
UF = cat(2,V,flipdim(V(1:Nx,2:Ny-1),2));
UF = fft(UF')'; 
V = UF(1:Nx,1:Ny);
end

function V = irfft2(U)
[Nx Ny] = size(U);
UF = cat(1,U,flipdim(U(2:Nx-1,1:Ny),1));
UF = ifft(UF); 
V = UF(1:Nx,1:Ny);
UF = cat(2,V,flipdim(V(1:Nx,2:Ny-1),2));
UF = ifft(UF')'; 
V = UF(1:Nx,1:Ny);
end

function [Het,phi] = compute_HetPhi(Dx,Dy,dt)
global epsilon;
global D;
global kappa;
NN = length(Dx);  MM = length(Dy);
Het = zeros(NN,MM);
phi = zeros(NN,MM,3); 
for i=1:NN
    for j=1:MM
        Hij = D*(Dx(i)+Dy(j))^2*epsilon^2-kappa*D*(Dx(i)+Dy(j));
        if abs(Hij)>1.0e-6
           Het(i,j) = exp(-Hij*dt); 
           phi(i,j,1) = (1-Het(i,j))/Hij; 
           phi(i,j,2) = (1-phi(i,j,1)/dt)/Hij;
           phi(i,j,3) = (1-2*phi(i,j,2)/dt)/Hij;
        else
           Het(i,j) = 1;
           phi(i,j,1) = dt; 
           phi(i,j,2) = dt/2;
           phi(i,j,3) = dt/3;
        end
    end
end
end

function int = int_F(phi,F,ord)
[NN MM nn] = size(F);
int = sparse(NN,MM);
if ord==1 
   int = phi(:,:,1).*F(:,:,1);
end
if ord==2 
   int = (phi(:,:,1)+phi(:,:,2)).*F(:,:,1)-phi(:,:,2).*F(:,:,2);
end
if ord==3
   int = 0.5*(2*phi(:,:,1)+3*phi(:,:,2)+phi(:,:,3)).*F(:,:,1) ...
              -(2*phi(:,:,2)+phi(:,:,3)).*F(:,:,2) ...
              +0.5*(phi(:,:,2)+phi(:,:,3)).*F(:,:,3);
end
end

function [vol,egy] = comput_Vol_Egy(U,hx,hy,bct)
global epsilon;
[NN MM] = size(U);
V = (U+1)/2;
%Computing volume
if bct==1
   vol = sum(sum(V));
end
if bct==2
   vol = sum(sum(V(2:NN-1,2:MM-1)))+0.5*(sum(V(1,2:MM-1))+sum(V(NN,2:MM-1)) ...
         +sum(V(2:NN-1,1))+sum(V(2:NN-1,MM)))+0.25*(V(1,1)+V(1,MM)+V(NN,1)+V(NN,MM));
end
vol = vol*hx*hy;
%Computing energy
if bct==1
   V = 0.5*((U(2:NN,1:MM)-U(1:NN-1,1:MM))/hx).^2;
   V(NN,1:MM) = 0.5*((U(1,1:MM)-U(NN,1:MM))/hx).^2;
   V(1:NN,MM+1) = V(1:NN,1); 
   egy = sum(sum(V(1:NN,2:MM)))+0.5*(sum(V(1:NN,1))+sum(V(1:NN,MM+1)));
   V = 0.5*((U(1:NN,2:MM)-U(1:NN,1:MM-1))/hy).^2;
   V(1:NN,MM) = 0.5*((U(1:NN,1)-U(1:NN,MM))/hy).^2;
   V(NN+1,1:MM) = V(1,1:MM); 
   egy = egy+sum(sum(V(2:NN,1:MM)))+0.5*(sum(V(1,1:MM))+sum(V(NN+1,1:MM)));
   V = 0.25*(U.*U-1).^2/epsilon^2;
   egy = egy+sum(sum(V));
end
if bct==2
   V = 0.5*((U(2:NN,1:MM)-U(1:NN-1,1:MM))/hx).^2; 
   egy = sum(sum(V(1:NN-1,2:MM-1)))+0.5*(sum(V(1:NN-1,1))+sum(V(1:NN-1,MM)));
   V = 0.5*((U(1:NN,2:MM)-U(1:NN,1:MM-1))/hy).^2;
   egy = egy+sum(sum(V(2:NN-1,1:MM-1)))+0.5*(sum(V(1,1:MM-1))+sum(V(NN,1:MM-1)));
   V = 0.25*(U.*U-1).^2/epsilon^2;
   egy = egy+sum(sum(V(2:NN-1,2:MM-1)))+0.5*(sum(V(1,2:MM-1))+sum(V(NN,2:MM-1)) ...
         +sum(V(2:NN-1,1))+sum(V(2:NN-1,MM)))+0.25*(V(1,1)+V(1,MM)+V(NN,1)+V(NN,MM));
end
egy = egy*hx*hy;
end

function U_full = Recover(U,bct)
[NN MM] = size(U);
if bct==1
   U_full = zeros(NN+1,MM+1);
   U_full(1:NN,1:MM) = U(1:NN,1:MM);
   U_full(1:NN,MM+1) = U_full(1:NN,1);
   U_full(NN+1,1:MM+1) = U_full(1,1:MM+1);
end  
if bct==2
   U_full = U;
end
end

function V = FF(U,hx,hy)
global epsilon;
global D;
global A;
global B;
global kappa;
global il;
global ir;
global jl;
global jr;
[NN MM] = size(U);
UL = circle_x(A,U)+circle_y(B,U);
V = D*(circle_x(A,U.*U.*U)+circle_y(B,U.*U.*U)-(1+kappa)*UL);
UL = U.*(U.^2-1)-UL*epsilon^2;
DL = Mu(U)-D;
ratx = hy/hx; raty = hx/hy; hxy = 1/(hx*hy);
for i=1:NN
    for j=1:MM
        ce = 0.5*(DL(i,j)+DL(il(i),j))*ratx; 
        cw = 0.5*(DL(i,j)+DL(ir(i),j))*ratx; 
        cs = 0.5*(DL(i,j)+DL(i,jl(j)))*raty; 
        cn = 0.5*(DL(i,j)+DL(i,jr(j)))*raty; 
        V(i,j) = V(i,j)+hxy*(ce*UL(il(i),j)+cw*UL(ir(i),j) ...
                       +cs*UL(i,jl(j))+cn*UL(i,jr(j)) ...
                       -(ce+cs+cw+cn)*UL(i,j));
    end
end
end

function V = Mu(U)
V = abs(1-U.*U);
%V = 0.5*abs(1+U);
%V = ones(size(U));
end

function uu = u0(x,y)
global epsilon;
% R0 = 0.3;
% dr = max(abs(x),abs(y));
% uu = tanh((R0-dr)/(sqrt(2)*epsilon));
% uu = (-1+2*rand(1,1))*0.1;
phi = 0.25;
%phi = 0.75;
%phi = 0.5;
uu = 2*phi-1+(-1+2*rand(1,1))*0.2;
end