function cEIF_AllenCahn2D(N,M,K,bct,ord)
format long

%This program solve the Allen-Cahn equation 
%  u_t = D(\Delta(u)-(u^3-u)/epsilon^2)

%Boundary condition type
%bct = 1; % Periodic bc
%bct = 2; % No-flux bc

%Order of accuracy in time
%ord = 1; 
%ord = 2; 
%ord = 3; 

%Domain
%  [xb,xe] x [yb,ye]
%Number of grid sizes 
%   N x M 
%Time interval
%  [T0,Te] 
%Number of step sizes
%   K

%Allen-Cahn parameters
global epsilon;
global D;
global R0;
global kappa;
epsilon = 0.02;
D = 1;
kappa = 2*D/epsilon^2;
R0 = 0.4;

xb = -0.5; xe = 0.5; yb = -0.5; ye = 0.5; T0 = 0; Te = 0.075;
hx = (xe-xb)/N;  hy = (ye-yb)/M;
x = xb:hx:xe;  y = yb:hy:ye;
dt = (Te-T0)/K;  T = T0:dt:Te;

fprintf(1,'\n *************************************************\n');
fprintf(1,'\n --- Parameters and Mesh Sizes ---\n');
fprintf(1,'\n epsilon = %e, D = %e\n',epsilon,D);
fprintf(1,'\n Nx = %d, Ny = %d, Nt = %d\n',N,M,K);
fprintf(1,'\n hx = %e, hy = %e, dt = %e\n',hx,hy,dt);
if bct==1
   fprintf(1,'\n Boundary Condition Type: Periodic\n');
end
if bct==2
   fprintf(1,'\n Boundary Condition Type: Neumann \n');
end

%Compute A and B
if bct==1
   NN = N; MM = M;
   A = zeros(NN,NN);  B = zeros(MM,MM);
   for i=1:NN-1
       A(i,i) = -2;  A(i,i+1) = 1;  A(i+1,i) = 1;
   end
   A(NN,NN) = -2;  A(1,NN) = 1;  A(NN,1) = 1;
   for i=1:MM-1
       B(i,i) = -2;  B(i,i+1) = 1;  B(i+1,i) = 1;
   end
   B(MM,MM) = -2;  B(1,MM) = 1;  B(MM,1) = 1;
end
if bct==2
   NN = N+1; MM = M+1;
   A = zeros(NN,NN);  B = zeros(MM,MM);
   for i=1:NN-1
       A(i,i) = -2;  A(i,i+1) = 1;  A(i+1,i) = 1;
   end
   A(NN,NN) = -2;  A(1,2) = 2; A(NN,NN-1) = 2;
   for i=1:MM-1
       B(i,i) = -2;  B(i,i+1) = 1;  B(i+1,i) = 1;
   end
   B(MM,MM) = -2;  B(1,2) = 2;  B(MM,MM-1) = 2;
end

%Diagonalize A,B
A = D*A/(hx*hx);
[Px,Dx]=eig(A);
%Px; Dx;
Pxi = inv(Px);
B = D*B/(hy*hy);
[Py,Dy]=eig(B);
%Py; Dy;
Pyi = inv(Py);

Het = zeros(NN,MM);
phi = zeros(NN,MM,3); 
for i=1:NN
    for j=1:MM
        Hij = Dx(i,i)+Dy(j,j)-kappa;
        if abs(Hij)>1.0e-3
           Het(i,j) = exp(Hij*dt); 
           phi(i,j,1) = -(1-Het(i,j))/Hij; 
           phi(i,j,2) = -(1-phi(i,j,1)/dt)/Hij;
           phi(i,j,3) = -(1-2*phi(i,j,2)/dt)/Hij;
        else
           Het(i,j) = 1;
           phi(i,j,1) = dt; 
           phi(i,j,2) = dt/2;
           phi(i,j,3) = dt/3;
        end
    end
end

%Initialize U0
U = zeros(NN,MM);
for i=1:NN
    for j=1:MM
        U(i,j) = u0(x(i),y(j));
    end
end

F = zeros(NN,MM,3);

tic

%Evolve U along the time
F(:,:,1) = circle_y(Pyi,circle_x(Pxi,FF(U)));
TK = K;
vol =  0:1:TK;
egy =  0:1:TK;
U_full = Recover(U,bct);
[vol(1),egy(1)] = comput_Vol_Egy(U_full,hx,hy);
kstop = TK;
c_ord = ord;
for k=1:TK
    itrue = 1;
    egy_old = egy(k);
    U_lin = circle_y(Pyi,circle_x(Pxi,U)).*Het;
    while itrue==1
    U = circle_y(Py,circle_x(Px,U_lin-int_F(phi,F,min(min(k,ord),c_ord))));
    U_full = Recover(U,bct);
    [vol(k+1),egy(k+1)] = comput_Vol_Egy(U_full,hx,hy);
    if egy_old<egy(k+1)&&c_ord>1
       c_ord = max(c_ord-1,1);  
    else
       c_ord = min(ord,c_ord+1);
       itrue = 0;
    end
    end 
    if abs(egy_old-egy(k+1))<max(egy_old,100)*1.0e-6
       kstop = k;
       break;
    end
    if k==1
       F(:,:,2) = F(:,:,1);
    end
    if k>1
       F(:,:,3) = F(:,:,2);
       F(:,:,2) = F(:,:,1);
    end
    F(:,:,1) = circle_y(Pyi,circle_x(Pxi,FF(U)));
end

wtime = toc;
fprintf (1,'\n MY_PROGRAM took %f seconds to run !!!\n',wtime);

if kstop==TK
   fprintf(1,'\n --- A Steady State Had Not Been Reached at T = %e ---\n',T(kstop+1));
else
   fprintf(1,'\n --- A Steady State Was Reached at T = %e ---\n',T(kstop+1));
end
fprintf(1,'\n Minimal value = %f, Maximal value = %f\n',min(min(U)),max(max(U)));
fprintf(1,'\n Initial energy = %e, Final energy is %e\n',egy(1),egy(kstop+1));
fprintf(1,'\n Initial volume = %e, Final volume is %e\n',vol(1),vol(kstop+1));
Rtrue = sqrt(R0^2-2*T(TK+1));
R = sqrt(vol(kstop+1)/pi);
fprintf(1,'\n Final Radius = %f, True Radius = %f, Error = %e\n',R, ...
          Rtrue,R-Rtrue);
fprintf(1,'\n *************************************************\n');

%Draw the solution at the end time 
fig1 = figure();
surf(x,y,U_full','linestyle','none');
xlabel('X');
ylabel('Y');
axis equal;
colorbar;
view([0,0,1]);

%Draw the volume and energy curves along the time 
fig2 = figure();
plot(T(1:kstop+1),vol(1:kstop+1),'.-');
xlabel('Time');
ylabel('Volume');
fig3 = figure();
plot(T(1:kstop+1),egy(1:kstop+1),'.-');
xlabel('Time');
ylabel('Energy');
end

function V = circle_x(P,U)
V = P*U;
end

function V = circle_y(P,U)
V = U*P';
end

function int = int_F(phi,F,ord)
NN = size(F,1);  MM = size(F,2);
int = sparse(NN,MM);
if ord==1 
   int = phi(:,:,1).*F(:,:,1);
end
if ord==2 
   int = (phi(:,:,1)+phi(:,:,2)).*F(:,:,1)-phi(:,:,2).*F(:,:,2);
end
if ord==3 
   int = 0.5*(2*phi(:,:,1)+3*phi(:,:,2)+phi(:,:,3)).*F(:,:,1) ...
              -(2*phi(:,:,2)+phi(:,:,3)).*F(:,:,2) ...
              +0.5*(phi(:,:,2)+phi(:,:,3)).*F(:,:,3);
end 
end

function [vol,egy] = comput_Vol_Egy(U,hx,hy)
global epsilon;
N = size(U,1);  M = size(U,2);
vol = 0;
egy1 = 0;  egy2 = 0;
for i=1:N-1
    for j=1:M-1
        uu = 0.25*(U(i,j)+U(i+1,j)+U(i,j+1)+U(i+1,j+1));
        vol = vol+(uu+1)/2;
        egy1 = egy1+(uu*uu-1)^2;
        udx = 0.5*(U(i+1,j)-U(i,j)+U(i+1,j+1)-U(i,j+1))/hx;
        udy = 0.5*(U(i,j+1)-U(i,j)+U(i+1,j+1)-U(i+1,j))/hy;
        egy2 = egy2+(udx*udx+udy*udy);
    end
end
vol = vol*hx*hy;
egy1 = 0.25*egy1/epsilon^2;
egy2 = 0.5*egy2;
egy = (egy1+egy2)*hx*hy;
end

function U_full = Recover(U,bct)
NN = size(U,1);  MM = size(U,2);
if bct==1
   U_full = zeros(NN+1,MM+1);
   U_full(1:NN,1:MM) = U(1:NN,1:MM);
   U_full(1:NN,MM+1) = U_full(1:NN,1);
   U_full(NN+1,1:MM+1) = U_full(1,1:MM+1);
end  
if bct==2
   U_full = U;
end
end

function V = FF_org(U)
global epsilon;
global D;
V = D*U.*(U.*U-1)/epsilon^2;
end

function V = FF(U)
global kappa;
V = FF_org(U)-kappa*U;
end

function uu = u0(x,y)
global epsilon;
global R0;
dr = sqrt(x^2+y^2);
uu = tanh((R0-dr)/(sqrt(2)*epsilon));
end

