function cEIF_AllenCahn3D(N,M,L,K,bct,ord)
format long

%This program solve the Allen-Cahn equation 
%  u_t = D(\Delta(u)-(u^3-u)/epsilon^2)

%Boundary condition type
%bct = 1; % Periodic bc
%bct = 2; % Neumann bc

%Order of accuracy in time
%ord = 1; 
%ord = 2; 
%ord = 3; 

%Domain
%  [xb,xe] x [yb,ye] x [zb,ze]
%Number of grid sizes 
%   N x M x L
%Time interval
%  [T0,Te] 
%Number of step sizes
%   K

%Allen-Cahn parameters
global epsilon;
global D;
global R0;
global kappa;
epsilon = 0.02;
D = 1;
kappa = 2*D/epsilon^2;
R0 = 0.4;

xb = -0.5; xe = 0.5; yb = -0.5; ye = 0.5; zb = -0.5; ze = 0.5;
T0 = 0; Te = 0.0375;
hx = (xe-xb)/N;  hy = (ye-yb)/M;  hz = (ze-zb)/L;
x = xb:hx:xe;  y = yb:hy:ye;  z = zb:hz:ze;
dt = (Te-T0)/K;  T = T0:dt:Te;

fprintf(1,'\n *************************************************\n');
fprintf(1,'\n --- Parameters and Mesh Sizes ---\n');
fprintf(1,'\n epsilon = %e, D = %e\n',epsilon,D);
fprintf(1,'\n Nx = %d, Ny = %d, Nz = %d, Nt = %d\n',N,M,L,K);
fprintf(1,'\n hx = %e, hy = %e, hz = %e, dt = %e\n',hx,hy,hz,dt);

if bct==1
   fprintf(1,'\n Boundary Condition Type: Periodic\n');
end
if bct==2
   fprintf(1,'\n Boundary Condition Type: Neumann \n');
end

%Compute A,B,C
if bct==1
   NN = N; MM = M; LL = L;
   A = zeros(NN,NN);  B = zeros(MM,MM);  C=zeros(LL,LL); 
   for i=1:NN-1
       A(i,i) = -2;  A(i,i+1) = 1;  A(i+1,i) = 1;
   end
   A(NN,NN) = -2;  A(1,NN) = 1;  A(NN,1) = 1;
   for i=1:MM-1
       B(i,i) = -2;  B(i,i+1) = 1;  B(i+1,i) = 1;
   end
   B(MM,MM) = -2;  B(1,MM) = 1;  B(MM,1) = 1;
   for i=1:LL-1
       C(i,i) = -2;  C(i,i+1) = 1;  C(i+1,i) = 1;
   end
   C(LL,LL) = -2;  C(1,LL) = 1;  C(LL,1) = 1;
end
if bct==2
   NN = N+1; MM = M+1; LL = L+1;
   A = zeros(NN,NN);  B = zeros(MM,MM);  C=zeros(LL,LL);
   for i=1:NN-1
       A(i,i) = -2;  A(i,i+1) = 1;  A(i+1,i) = 1;
   end
   A(NN,NN) = -2;  A(1,2) = 2; A(NN,NN-1) = 2;
   for i=1:MM-1
       B(i,i) = -2;  B(i,i+1) = 1;  B(i+1,i) = 1;
   end
   B(MM,MM) = -2;  B(1,2) = 2;  B(MM,MM-1) = 2;
   for i=1:LL-1
       C(i,i) = -2;  C(i,i+1) = 1;  C(i+1,i) = 1;
   end
   C(LL,LL) = -2;  C(1,2) = 2;  C(LL,LL-1) = 2;
end

%Diagonalize A,B,C
A = D*A/(hx*hx);
[Px,Dx]=eig(A);
%Px; Dx;
Pxi = inv(Px);
B = D*B/(hy*hy);
[Py,Dy]=eig(B);
%Py; Dy;
Pyi = inv(Py);
C = D*C/(hz*hz);
[Pz,Dz]=eig(C);
%Pz; Dz;
Pzi = inv(Pz);

Het = zeros(NN,MM,LL);
phi = zeros(NN,MM,LL,3);
for i=1:NN
    for j=1:MM
        for l = 1:LL
            Hijl = Dx(i,i)+Dy(j,j)+Dz(l,l)-kappa;
            if abs(Hijl)>1.0e-3
               Het(i,j,l) = exp(Hijl*dt); 
               phi(i,j,l,1) = -(1-Het(i,j,l))/Hijl; 
               phi(i,j,l,2) = -(1-phi(i,j,l,1)/dt)/Hijl;
               phi(i,j,l,3) = -(1-2*phi(i,j,l,2)/dt)/Hijl;
            else
               Het(i,j,l) = 1;
               phi(i,j,l,1) = dt; 
               phi(i,j,l,2) = dt/2;
               phi(i,j,l,3) = dt/3;
            end
        end
    end
end

%Initialize U0
U = zeros(NN,MM,LL);
for i=1:NN
    for j=1:MM
        for l=1:LL
            U(i,j,l) = u0(x(i),y(j),z(l));
        end
    end
end

F = zeros(NN,MM,LL,3);

tic;

%Evolve U along the time
F(:,:,:,1) = circle_z(Pzi,circle_y(Pyi,circle_x(Pxi,FF(U))));
TK = K;
vol =  0:1:TK;
egy =  0:1:TK;
U_full = Recover(U,bct);
Vsurf1 = extract_pts(U_full,x,y,z);
[vol(1),egy(1)] = comput_Vol_Egy(U_full,hx,hy,hz);
kstop = TK;
timeshow = [0.02 0.0375];
c_ord = ord;
for k=1:TK
    itrue = 1;
    egy_old = egy(k);
    U_lin = circle_z(Pzi,circle_y(Pyi,circle_x(Pxi,U))).*Het;
    while itrue==1
    U = circle_z(Pz,circle_y(Py,circle_x(Px,U_lin-int_F(phi,F,min(min(k,ord),c_ord)))));
    U_full = Recover(U,bct);
    [vol(k+1),egy(k+1)] = comput_Vol_Egy(U_full,hx,hy,hz);
    if egy_old<egy(k+1)&&c_ord>1
       c_ord = max(c_ord-1,1);  
    else
       c_ord = min(ord,c_ord+1);
       itrue = 0;
    end
    end 
    if timeshow(1)<=T(k+1)+dt/10&&timeshow(1)>T(k)+dt/10
       Vsurf2 = extract_pts(U_full,x,y,z);
    end
    if timeshow(2)<=T(k+1)+dt/10&&timeshow(2)>T(k)+dt/10
       Vsurf3 = extract_pts(U_full,x,y,z);
    end
    if abs(egy_old-egy(k+1))<max(egy_old,100)*1.0e-6
       kstop = k;
       break;
    end
    if k==1
       F(:,:,:,2) = F(:,:,:,1);
    end
    if k>1
       F(:,:,:,3) = F(:,:,:,2);
       F(:,:,:,2) = F(:,:,:,1);
    end
    F(:,:,:,1) = circle_z(Pzi,circle_y(Pyi,circle_x(Pxi,FF(U))));
end

wtime = toc;
fprintf (1,'\n MY_PROGRAM took %f seconds to run !!!\n',wtime);

if kstop==TK
   fprintf(1,'\n --- A Steady State Had Not Been Reached at T = %e ---\n',T(kstop+1));
else
   fprintf(1,'\n --- A Steady State Was Reached at T = %e ---\n',T(kstop+1));
end
fprintf(1,'\n Minimal value = %f, Maximal value = %f\n',min(min(min(U))), ...
              max(max(max(U))));
fprintf(1,'\n Initial energy = %e, Final energy is %e\n',egy(1),egy(kstop+1));
fprintf(1,'\n Initial volume = %e, Final volume is %e\n',vol(1),vol(kstop+1));
Rtrue = sqrt(R0^2-4*T(TK+1));
R = (3*vol(kstop+1)/(4*pi))^(1/3);
fprintf(1,'\n Final Radius = %f, True Radius = %f, Error = %e\n',R, ...
          Rtrue,R-Rtrue);
fprintf(1,'\n *************************************************\n');

%save('vol_egy.mat','vol','egy');

%Draw the solution at the end time at the plane z=0
fig1 = figure();
UZ0 = U_full(1:N+1,1:M+1,1+L/2);
surf(x,y,UZ0','linestyle','none');
xlabel('X');
ylabel('Y');
axis equal;
colorbar;
%view([0,0,1]);

%Draw the volume and energy curves along the time 
fig2 = figure();
plot(T(1:kstop+1),(vol(1:kstop+1)).^(2/3),'.-');
xlabel('Time');
ylabel('Volume^{2/3}');
fig3 = figure();
plot(T(1:kstop+1),egy(1:kstop+1),'.-');
xlabel('Time');
ylabel('Energy');

%Draw surfaces
fig4 = figure('Position',[1,1,425,425]);
draw_surf(Vsurf1);
shading interp;
colormap copper;
xlabel('X');
ylabel('Y');
zlabel('Z');
axis([-0.5 0.5 -0.5 0.5 -0.5 0.5]);
%axis equal;
fig5 = figure('Position',[1,1,425,425]);
draw_surf(Vsurf2);
shading interp;
colormap copper;
xlabel('X');
ylabel('Y');
zlabel('Z');
axis([-0.5 0.5 -0.5 0.5 -0.5 0.5]);
%axis equal;
fig6 = figure('Position',[1,1,425,425]);
draw_surf(Vsurf3);
shading interp;
colormap copper;
xlabel('X');
ylabel('Y');
zlabel('Z');
axis([-0.5 0.5 -0.5 0.5 -0.5 0.5]);
%axis equal;
end

function V = circle_x(P,U)
V = U;
for l=1:size(U,3)
    V(:,:,l) = P*U(:,:,l);
end
end

function V = circle_y(P,U)
V = U;
for i=1:size(U,1)
    U1(:,:) = U(i,:,:);
    V1 = P*U1;
    V(i,:,:) = V1;
end
end

function V = circle_z(P,U)
V = U;
for j=1:size(U,2)
    U1(:,:) = U(:,j,:);
    V1= U1*P'; 
    V(:,j,:) = V1;
end
end

function int = int_F(phi,F,ord)
NN = size(F,1);  MM = size(F,2);  LL = size(F,3);
int = zeros(NN,MM,LL);
if ord==1
   int = phi(:,:,:,1).*F(:,:,:,1);
end
if ord==2 
   int = (phi(:,:,:,1)+phi(:,:,:,2)).*F(:,:,:,1)-phi(:,:,:,2).*F(:,:,:,2);
end
if ord==3 
   int = 0.5*(2*phi(:,:,:,1)+3*phi(:,:,:,2)+phi(:,:,:,3)).*F(:,:,:,1) ...
              -(2*phi(:,:,:,2)+phi(:,:,:,3)).*F(:,:,:,2) ...
              +0.5*(phi(:,:,:,2)+phi(:,:,:,3)).*F(:,:,:,3);
end 
end

function [vol,egy] = comput_Vol_Egy(U,hx,hy,hz)
global epsilon;
N = size(U,1);  M = size(U,2);  L = size(U,3);
vol = 0;
egy1 = 0;  egy2 = 0;
for i=1:N-1
   for j=1:M-1
      for l=1:L-1
        uu = 0.125*(U(i,j,l)+U(i+1,j,l)+U(i,j+1,l)+U(i+1,j+1,l) ...
              +U(i,j,l+1)+U(i+1,j,l+1)+U(i,j+1,l+1)+U(i+1,j+1,l+1));
        vol = vol+(uu+1)/2;
        egy1 = egy1+(uu*uu-1)^2;
        udx = 0.25*(U(i+1,j,l)-U(i,j,l)+U(i+1,j+1,l)-U(i,j+1,l) ...
               +U(i+1,j,l+1)-U(i,j,l+1)+U(i+1,j+1,l+1)-U(i,j+1,l+1))/hx;
        udy = 0.25*(U(i,j+1,l)-U(i,j,l)+U(i+1,j+1,l)-U(i+1,j,l) ...
               +U(i+1,j,l+1)-U(i,j,l+1)+U(i+1,j+1,l+1)-U(i,j+1,l+1))/hy;
        udz = 0.25*(U(i,j,l+1)-U(i,j,l)+U(i,j+1,l+1)-U(i,j+1,l) ...
               +U(i+1,j,l+1)-U(i+1,j,l)+U(i+1,j+1,l+1)-U(i+1,j+1,l))/hz;
        egy2 = egy2+(udx*udx+udy*udy+udz*udz);
      end
   end
end
vol = vol*hx*hy*hz;
egy1 = 0.25*egy1/epsilon^2;
egy2 = 0.5*egy2;
egy = (egy1+egy2)*hx*hy*hz;
end

function U_full = Recover(U,bct)
NN = size(U,1);  MM = size(U,2);  LL = size(U,3);
if bct==1
   U_full = zeros(NN+1,MM+1,LL+1); 
   U_full(1:NN,1:MM,1:LL) = U(1:NN,1:MM,1:LL);
   U_full(1:NN,1:MM,LL+1) = U_full(1:NN,1:MM,1);
   U_full(1:NN,MM+1,1:LL+1) = U_full(1:NN,1,1:LL+1);
   U_full(NN+1,1:MM+1,1:LL+1) = U_full(1,1:MM+1,1:LL+1);
end  
if bct==2
   U_full = U;
end
end

function V = extract_pts(U,x,y,z)
N = size(U,1);  M = size(U,2);  L = size(U,3);
npt = 0;
slimit = 0.8;
for i=1:N
    for j=1:M
        for l=1:L
            if abs(U(i,j,l))<slimit 
               npt = npt+1;
               V(npt,1) = x(i); V(npt,2) = y(j); V(npt,3) = z(l); 
            end
        end
    end
end
end

function draw_surf(V)
X = V(:,1);
Y = V(:,2);
Z = V(:,3);
C = rand(size(X));
scatter3(X,Y,Z,5,C);
DT = DelaunayTri(X, Y, Z);
[tri,Xb]=freeBoundary(DT);
% map Xb onto V
[~,IA,IB]=intersect(V,Xb,'rows');
% extract the needed colors using the IA map
Cn = C(IA);
% permute the surface triangulation points using IB map
Xbn = Xb(IB,:);
% map the point numbers used in triangle definitions
% NOTE: for that you need inverse map
iIB(IB) = 1:length(IB);
trin = iIB(tri);
trisurf(trin,Xbn(:,1),Xbn(:,2),Xbn(:,3),'EdgeAlpha',0,'FaceColor','red');
%trisurf(trin,Xbn(:,1),Xbn(:,2),Xbn(:,3),Cn,'EdgeAlpha',0,'FaceColor','interp');
end

function V = FF_org(U)
global epsilon;
global D;
V = D*U.*(U.*U-1)/epsilon^2;
end

function V = FF(U)
global kappa;
V = FF_org(U)-kappa*U;
end

function uu = u0(x,y,z)
global epsilon;
global R0;
dr = sqrt(x^2+y^2+z^2);
uu = tanh((R0-dr)/(sqrt(2)*epsilon));
end
